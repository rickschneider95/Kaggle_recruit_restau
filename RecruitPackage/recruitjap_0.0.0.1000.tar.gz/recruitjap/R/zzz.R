globalVariables(c(
  # area_transf.R
  "area_name",
  # barrest_transf.R
  "genre_name",
  # bme_rmonth_transf.R
  "reserve_date",
  # bme_vmonth_transf.R
  "visit_date",
  # dn_transf.R
  "visit_time",
  # goldd_transf.R
  "goldendays",
  # goldw_transf.R
  "goldenweek",
  # lag_transf.R
  "id","visitors","latitude",
  # latency_transf.R
  "latency_days",
  # lon_transf.R
  "longitude",
  # vdayweek_transf.R
  "day_of_the_week_visit",
  # rdayweek_transf.R,
  "day_of_the_week_reserve",
  # vholflg_transf.R
  "holiday_flg_visit",
  # vholflg_transf.R
  "holiday_flg_reserve",
  # wealth_transf.R
  "wealth",
  # wknd_transf.R
  "wknd",
  # rtime_transf.R
  "reserve_time",
  # shinyapp.R
  "dir"
))
